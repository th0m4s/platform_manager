#!/bin/env node
// can run on windows with .bat file

console.log(process.argv);