const fs = require("fs");
const path = require("path");
const utils = require("../utils");
const bent = require("bent");
const execa = require("execa");

function getCommands() {
    return {
        start: {help: "Start the current project.", needProject: true},
        stop: {help: "Stop the current project.", needProject: true},
        init: {help: "Initialize a folder as a PMNG project."}
    };
}

function setGitRemote(projectname, save) {
    if(save == undefined) save = utils.getSave();
    let gitRepoUrl = save.adminServer.replace("admin.", save.account.username + ":" + save.account.token + "@git.") + projectname + ".git";

    let gitRemoteList = execa.sync("git", ["remote"], {shell: true});
    if(gitRemoteList.failed || gitRemoteList.exitCode != 0) return;

    let remotes = gitRemoteList.stdout.toString().trim().split("\n");
    let command = remotes.includes("pmng") ? "set-url" : "add";

    let gitRemoteSet = execa.sync("git", ["remote", command, "pmng", gitRepoUrl], {shell: true});
    if(gitRemoteSet.failed || gitRemoteSet.exitCode != 0) {
        console.error("Cannot set Git remote (status/signal " + (gitRemoteSet.exitCode || gitRemoteSet.killSignal) + "): " + (gitRemoteSet.message || gitRemoteSet.stderr.toString().trim()));
        process.exit(1);
    }

    if(command == "add") {
        if(utils.pullProject()) {
            let gitUpstream = execa.sync("git", ["branch", "-u", "pmng/master"], {shell: true});
            if(gitUpstream.failed || gitUpstream.exitCode != 0) {
                console.error("WARNING: Setup could not set default upstream remote. The the pmng/master branch manually pulling/pushing.\n");
                return -1;
            } else return 1;
        } else {
            console.error("WARNING: Setup could not pull the current state of the repository. Please use 'git pull pmng master' before using this folder.\n");
            return -1;
        }
    } return 0;// else repo already exists
}

function checkGitignore() {
    let gitignorePath = path.resolve(process.cwd(), ".gitignore");
    let gitignoreLines = [], correctLine = "/.pmng.json";

    let lineAdded = true;
    if(fs.existsSync(gitignorePath)) {
        gitignoreLines = fs.readFileSync(gitignorePath).toString().split("\n");

        if(!gitignoreLines.some((line) => {
            return line == correctLine;
        })) {
            let lastI = gitignoreLines.length-1;
            if(gitignoreLines[lastI].trim().length == 0) gitignoreLines[lastI] = correctLine;
            else gitignoreLines.push(correctLine);
        } else lineAdded = false;
    } else gitignoreLines.push(correctLine);

    fs.writeFileSync(gitignorePath, gitignoreLines.join("\n") + "\n");

    return lineAdded;
}

async function executeCommand(command, args, {quiet, forceYes}) {
    let currentProjectConfig = utils.getProjectConfig(), projectname = currentProjectConfig.projectname || "";
    let save = utils.getSave(), projectGet = bent(save.adminServer + "/api/v1/projects", "GET", "json");
    switch(command) {
        case "init":
            utils.checkLoggedIn(save, "initializing a project");
            if(currentProjectConfig == false) {
                let defaultName = path.basename(process.cwd()).toLowerCase(), fromArg = false;
                if(args.length > 0) {
                    defaultName = args[0].trim();
                    fromArg = true;
                }

                let checkRegex = /^[a-z-0-9]{4,32}$/;
                if(!checkRegex.test(defaultName)) defaultName = "";

                if(!fromArg || defaultName == "") {
                    projectname = await utils.askQuestion("What project should be associated to this folder" + (defaultName != "" ? " (" + defaultName + ")" : "") + "? ", false);
                    if(projectname == "") projectname = defaultName;
                } else projectname = defaultName;

                if(!checkRegex.test(projectname)) {
                    console.error("Invalid project name.");
                    process.exit(1);
                }

                console.log("Checking project from server...");
                // using isrunning to check if project exists and correct privileges
                let initCheckError = (obj) => {
                    let message = (obj.code == 403 ? "You don't have the right to access this project." : (obj.code == 404 ? "This project doesn't exist on the remote server." : obj.message));
                    console.error("Cannot init this project (" + obj.code + "): " + message);
                    process.exit(1);
                }
                    
                try {
                    let initCheckResp = await projectGet("/isrunning/" + projectname, {}, utils.headerAuth(save.account.token));
                    if(initCheckResp.error || initCheckResp.code != 200) {
                        initCheckError(initCheckResp);
                    }
                } catch(error) {
                    try {
                        let response = await error.json();
                        initCheckError(response);
                    } catch(parseResponse) {
                        console.error("Invalid server response when initializing project: " + error);
                    }
    
                    process.exit(1);
                }

                // git init a second time (if git init was done before for example) is safe
                console.log("Setting up Git...");
                
                let gitInit = execa.sync("git", ["init"], {shell: true});
                if(gitInit.failed || gitInit.exitCode != 0) {
                    console.error("Cannot initialize Git repository (status/signal " + (gitInit.exitCode || gitInit.killSignal) + "): " + (gitInit.message || gitInit.stderr.toString().trim()));
                    process.exit(1);
                }

                let gitSetup = setGitRemote(projectname, save);
                let gitignoreModified = checkGitignore();
                
                console.log("Writing configuration...");
                utils.setProjectConfig({
                    cnfVersion: 1,
                    projectname
                });

                console.log("Project initialized.");

                if(gitignoreModified) {
                    if(gitSetup == 1) {
                        if(forceYes || (await utils.askConfirmation("\nThe .gitignore file was created/modified to exclude the local project configuration.\n"
                                + "Do you want to automatically commit and push this change (it will also rebuild the remote project)"))) {
                            let commitMessage = "Exclude local .pmng.json project config.";
                            if(!forceYes) {
                                let newMessage = await utils.askQuestion("\nThe commit message will be '" + commitMessage + "'.\n"
                                    + "Enter a new message to change it, leave empty to keep it and type .cancel to cancel this commit: ");
                                    if(newMessage.trim().length > 0) commitMessage = newMessage;
                            }

                            commitMessage = commitMessage.trim();
                            if(commitMessage.toLowerCase() != ".cancel") {
                                if(commitMessage.length <= 50) {

                                    let gitAdd = execa.sync("git", ["add", ".gitignore"], {shell: true});
                                    if(gitAdd.failed || gitAdd.exitCode != 0) {
                                        console.error("Cannot track your .gitignore file (status/signal " + (gitAdd.exitCode || gitAdd.killSignal) + ").");
                                        console.error("You'll have to manually track (with git add .gitignore) and commit this change change.");
                                    } else {
                                        let gitCommit = execa.sync("git", ["commit", "-am", '"' + commitMessage.replace(/"/g, '\\"') + '"'], {shell: true});
                                        if(gitCommit.failed || gitCommit.exitCode != 0) {
                                            console.error("Cannot commit this change to the repository (status/signal " + (gitCommit.exitCode || gitCommit.killSignal) + ").");
                                            console.error("You'll have to manually commit the .gitignore change.");
                                        } else {
                                            execa.sync("git", ["push", "pmng", "master"], {stdio: "inherit", shell: true});
                                            console.log("\Project folder initialized with correct .gitignore rules.");
                                        }
                                    }

                                } else console.error("Commit message length is over 50 chars. You'll have to manually commit this change.");
                            }
                        }
                    } else if(gitSetup == 0) {
                        console.log("\nGit repository already existed.\nYou'll have to manually commit and push the modified .gitignore rule to apply the .pmng.json exclusion rule.");
                    }
                }
            } else {
                console.error("This folder is already a PMNG project.");
                console.error("Remove the .pmng.json file if you want to reset the settings of this project.");
                process.exit(1);
            }
            break;
        case "stop":
        case "restart":
            utils.checkPMNGFolder(currentProjectConfig);
            utils.checkLoggedIn(save, "stopping this project");

            console.log("Stopping project " + projectname + "...");

            try {
                let stopResp = await projectGet("/stop/" + projectname, {}, utils.headerAuth(save.account.token));
                if(stopResp.error || stopResp.code != 200) {
                    console.error("Cannot stop the project (" +  startReq.code + "): " + startReq.message);
                    console.log("Please try again.");

                    process.exit(1);
                }
            } catch(error) {
                try {
                    let response = await error.json();
                    console.error("Status code " + response.code + ": " + response.message);
                } catch(parseResponse) {
                    console.error("Invalid server response when stopping project: " + error);
                }

                process.exit(1);
            }

            if(command != "restart") {
                console.log("Project " + projectname + " successfully stopped.");
                break;
            } else process.stdout.write("Project stopped.");
        case "start":
            utils.checkPMNGFolder(currentProjectConfig);
            utils.checkLoggedIn(save, "starting this project");

            let restart = command == "restart";
            if(restart) console.log(" Restarting...");
            else console.log("Starting project " + projectname + "...");

            let showTryAgain = () => {
                if(restart) console.error("\nWARNING: During the process, the project was stopped but not restarted.\n"
                    + "Please run pmng project:start or go to your admin panel.");
            }

            try {
                let startReq = await projectGet("/start/" + projectname, {}, utils.headerAuth(save.account.token));
                if(startReq.error || startReq.code != 200) {
                    console.error("Cannot start the project (" +  startReq.code + "): " + startReq.message);
                    showTryAgain();
                    process.exit(1);
                }
            } catch(error) {
                try {
                    let response = await error.json();
                    console.error("Status code " + response.code + ": " + response.message);
                } catch(parseResponse) {
                    console.error("Invalid server response when starting project: " + error);
                }

                showTryAgain();
                process.exit(1);
            }

            if(restart) console.log("\nProject " + projectname + " successfully restarted.");
            else console.log("Project " + projectname + " successfully started.");
            break;
        default:
            return false;
    }

    return true;
}

module.exports.getCommands = getCommands;
module.exports.executeCommand = executeCommand;