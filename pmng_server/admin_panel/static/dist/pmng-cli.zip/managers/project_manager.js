const fs = require("fs");
const path = require("path");
const utils = require("../utils");
const bent = require("bent");
const child_process = require("child_process");

function getCommands() {
    return {
        start: {help: "Start the current project.", needProject: true},
        stop: {help: "Stop the current project.", needProject: true},
        check: {help: "Check the configuration against the logged in user.", needProject: true},
        init: {help: "Initialize a folder as a PMNG project."}
    };
}

function getConfigFile(folder) {
    if(folder == undefined) folder = process.cwd();
    return path.resolve(folder, ".pmng.json");
}

function getProjectConfig(folder, throwError = false) {
    let configFile = getConfigFile(folder);
    try {
        return JSON.parse(fs.readFileSync(configFile).toString());
    } catch(error) {
        if(throwError) throw error;
        else return false;
    }
}

function setProjectConfig(save, folder) {
    fs.writeFileSync(getConfigFile(folder), JSON.stringify(save));
}

function setGitRemote(projectname, save) {
    if(save == undefined) save = utils.getSave();
    let gitRepoUrl = save.adminServer.replace("admin.", save.account.username + ":" + save.account.token + "@git.") + projectname + ".git";

    let gitRemoteList = child_process.spawnSync("/bin/env", ["git", "remote"]);
    if(gitRemoteList.error != undefined || gitRemoteList.status != 0) return;

    let remotes = gitRemoteList.stdout.toString().trim().split("\n");
    let command = remotes.includes("pmng") ? "set-url" : "add";

    let gitRemoteSet = child_process.spawnSync("/bin/env", ["git", "remote", command, "pmng", gitRepoUrl]);
    if(gitRemoteSet.error != undefined || gitRemoteSet.status != 0) {
        console.error("Cannot set Git remote (status/signal " + (gitRemoteSet.status || gitRemoteSet.signal) + "): " + (gitRemoteSet.error || gitRemoteSet.stderr.toString().trim()));
        process.exit(1);
    }

    if(command == "add") {
        if(pullProject()) {
            let gitUpstream = child_process.spawnSync("/bin/env", ["git", "branch", "-u", "pmng/master"]);
            if(gitUpstream.error != undefined || gitUpstream.status != 0) {
                console.error("WARNING: Setup could not set default upstream remote. The the pmng/master branch manually pulling/pushing.\n");
            }
        } else {
            console.error("WARNING: Setup could not pull the current state of the repository. Please use 'git pull pmng master' before using this folder.\n");
        }
    } // else repo already exists
}

function checkGitignore() {
    let gitignorePath = path.resolve(process.cwd(), ".gitignore");
    let gitignoreLines = [], correctLine = "/.pmng.json";

    if(fs.existsSync(gitignorePath)) {
        gitignoreLines = fs.readFileSync(gitignorePath).toString().split("\n");

        if(!gitignoreLines.some((line) => {
            return line == correctLine;
        })) {
            let lastI = gitignoreLines.length-1;
            if(gitignoreLines[lastI].trim().length == 0) gitignoreLines[lastI] = correctLine;
            else gitignoreLines.push(correctLine);
        }
    } else gitignoreLines.push(correctLine);

    fs.writeFileSync(gitignorePath, gitignoreLines.join("\n") + "\n");
}

function pullProject() {
    // here pull always use pmng/master because first pull requires it and to counter issues
    let gitPull = child_process.spawnSync("/bin/env", ["git", "pull", "pmng", "master"]);
    return !(gitPull.error != undefined || gitPull.status != 0);
}

async function executeCommand(command, args, {quiet, forceYes}) {
    let currentProjectConfig = getProjectConfig(), projectname = currentProjectConfig.projectname || "";
    let save = utils.getSave(), projectGet = bent(save.adminServer + "/api/v1/projects", "GET", "json");
    switch(command) {
        case "check":
            if(currentProjectConfig == false) {
                console.error("This is not a valid PMNG project folder.");
                process.exit(1);
            } else if(utils.isLoggedIn(save)) {
                console.log("Checking current session...");
                if(save.account.sessionId == currentProjectConfig.sessionId) {
                    console.log("User configuration matched.");
                } else {
                    setGitRemote(currentProjectConfig.projectname, save);
                    currentProjectConfig.sessionId = save.account.sessionId;
                    setProjectConfig(currentProjectConfig);
                    console.log("User configuration updated.");
                }
            } else {
                console.error("You are not logged in. Please use pmng sys:login before checking this folder.");
                process.exit(1);
            }
            break;
        case "init":
            if(currentProjectConfig == false) {
                if(utils.isLoggedIn(save)) {
                    let defaultName = path.basename(process.cwd());
                    let checkRegex = /^[a-z-0-9]{4,32}$/;
                    if(!checkRegex.test(defaultName)) defaultName = "";

                    let projectname = await utils.askQuestion("What project should be associated to this folder " + (defaultName != "" ? "(" + defaultName + ")" : "") + "? ", false);
                    if(projectname == "") projectname = defaultName;

                    if(!checkRegex.test(projectname)) {
                        console.error("Invalid project name.");
                        process.exit(1);
                    }

                    // git init a second time (if git init was done before for example) is safe
                    console.log("Setting up Git...");
                    
                    let gitInit = child_process.spawnSync("/bin/env", ["git", "init"]);
                    if(gitInit.error != undefined || gitInit.status != 0) {
                        console.error("Cannot initialize Git repository (status/signal " + (gitInit.status || gitInit.signal) + "): " + (gitInit.error || gitInit.stderr.toString().trim()));
                        process.exit(1);
                    }

                    setGitRemote(projectname, save);
                    checkGitignore();
                    
                    console.log("Writing configuration...");
                    setProjectConfig({
                        cnfVersion: 1,
                        projectname,
                        sessionId: save.account.sessionId
                    });

                    console.log("Project initialized.");
                } else {
                    console.error("You are not logged in. Please use pmng sys:login before initializing this folder.");
                    process.exit(1);
                }
            } else {
                console.error("This folder is already a PMNG project.");
                console.error("Remove the .pmng.json file if you want to reset the settings of this project.");
                process.exit(1);
            }
            break;
        case "stop":
        case "restart":
            console.log("Stopping project " + projectname + "...");

            try {
                let stopResp = await projectGet("/stop/" + projectname, {}, utils.headerAuth(save.account.token));
                if(stopResp.error || stopResp.code != 200) {
                    console.error("Cannot stop the project (" +  startReq.code + "): " + startReq.message);
                    console.log("Please try again.");

                    process.exit(1);
                }
            } catch(error) {
                try {
                    let response = await error.json();
                    console.error("Status code " + response.code + ": " + response.message);
                } catch(parseResponse) {
                    console.error("Invalid server response when stopping project: " + error);
                }

                process.exit(1);
            }

            if(command != "restart") {
                console.log("Project " + projectname + " successfully stopped.");
                break;
            } else process.stdout.write("Project stopped.");
        case "start":
            let restart = command == "restart";
            if(restart) console.log(" Restarting...");
            else console.log("Starting project " + projectname + "...");

            let showTryAgain = () => {
                if(restart) console.error("\nWARNING: During the process, the project was stopped but not restarted.\n"
                    + "Please run pmng project:start or go to your admin panel.");
            }

            try {
                let startReq = await projectGet("/start/" + projectname, {}, utils.headerAuth(save.account.token));
                if(startReq.error || startReq.code != 200) {
                    console.error("Cannot start the project (" +  startReq.code + "): " + startReq.message);
                    showTryAgain();
                    process.exit(1);
                }
            } catch(error) {
                try {
                    let response = await error.json();
                    console.error("Status code " + response.code + ": " + response.message);
                } catch(parseResponse) {
                    console.error("Invalid server response when starting project: " + error);
                }

                showTryAgain();
                process.exit(1);
            }

            if(restart) console.log("\nProject " + projectname + " successfully restarted.");
            else console.log("Project " + projectname + " successfully started.");
            break;
        default:
            return false;
    }

    return true;
}

module.exports.getCommands = getCommands;
module.exports.executeCommand = executeCommand;