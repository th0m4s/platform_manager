function getCommands() {
    return {
        view: {help: "Display all the logs for the project and exit.", needProject: true},
        download: {help: "Download a file of the logs of this project.", needProject: true},
        follow: {help: "Start following and display future log lines on the screen.", needProject: true}
    };
}

function executeCommand(command, args, {quiet, forceYes}) {
    return false;
}

module.exports.getCommands = getCommands;
module.exports.executeCommand = executeCommand;