const bent = require("bent");
const utils = require("../utils");
const fs = require("fs");

function getCommands() {
    return {
        view: {help: "Display all the logs for the project and exit.", needProject: true},
        download: {help: "Download a file of the logs of this project.", needProject: true},
        follow: {help: "Start following and display future log lines on the screen.", needProject: true}
    };
}

async function executeCommand(command, args, {quiet, forceYes}) {
    let currentProjectConfig = utils.getProjectConfig(), projectname = currentProjectConfig.projectname || "";
    let save = utils.getSave();

    switch(command) {
        case "view":
        case "download":
            utils.checkPMNGFolder(currentProjectConfig);

            let isSave = command == "download";
            utils.checkLoggedIn(save, command + "ing logs"); 

            let bentStream = bent(save.adminServer + "/api/v1/logs"), logsStream = await bentStream("/project/" + projectname + "/logs", {}, utils.headerAuth(save.account.token));

            try {
                await new Promise(async (resolve, reject) => {
                    logsStream.on("error", (error) => {
                        reject("An error occured while reading logs from the server: " + error);
                    });

                    if(isSave) {
                        let logsPath = "./project.log", confirmed = true;
                        if(fs.existsSync(logsPath)) {
                            confirmed = forceYes || (await utils.askConfirmation("A log file already exists in this folder. Do you want to overwrite it"));
                            if(confirmed && !forceYes) console.log(""); // margin line if question asked
                        }

                        if(confirmed) {
                            console.log("Saving logs to project.log...");
                            console.log("Don't forget to ignore/move the log file from Git to avoid unnecessary pushes.");
            
                            let saveStream = fs.createWriteStream(logsPath);
                            logsStream.pipe(saveStream);
            
                            saveStream.on("close", () => {
                                console.log("\nLogs saved to disk.");
                                resolve();
                            }).on("error", (error) => {
                                reject("An error occured while writing logs to disk: " + error);
                            });
                        } else resolve();
                    } else {
                        console.log("Showing logs for project " + projectname + ":");
                        logsStream.pipe(process.stdout, {end: false});
                        logsStream.on("end", resolve);
                    }
                });
            } catch(error) {
                console.error(error);
                process.exit(1);
            }

            break;
        case "follow":
        case "attach":
            utils.checkPMNGFolder(currentProjectConfig);
            utils.checkLoggedIn(save, "following project logs");

            let host = save.adminServer;
            if(!host.endsWith("/")) host += "/";

            try {
                await new Promise((resolve, reject) => {
                    console.log("Connecting to the admin socket server...");
                    let followSocket = require("socket.io-client")(host + "v1/logs");
                    followSocket.on("connect", () => {
                        console.log("Socket connected. Authenticating...");
                        followSocket.emit("authentication", {key: save.account.token});
                        followSocket.on("authenticated" , () => {
                            console.log("Authenticated. Connecting to project...");
                            followSocket.emit("project_logs", {project: projectname});
                        }).on("logs_start_position", () => {
                            // not using start pos, but used to indicate that server is ok with the projecrt
                            console.log("Socket initialized. Logs will automatically be displayed below:");
                        }).on("project_log", (message) => {
                            console.log(message.line);
                        }).on("unauthorized", (error) => {
                            reject("Unauthorized connection: " + error);
                        }).on("log_error", (error) => {
                            reject("An error occured while reading logs: " + error);
                        });
                        
                    }).on("error", (error) => {
                        reject("A socket error occured: " + error);
                    }).on("disconnect", (reason) => {
                        if(reason == "io server disconnect") {
                            reject("Server unexpectly closed the connection.");
                        } // else socket is autoreconnecting
                    });

                });
            } catch(error) {
                console.error(error);
                process.exit(1);
            }
            break;
        default:
            return false;
    }

    return true;
}

module.exports.getCommands = getCommands;
module.exports.executeCommand = executeCommand;