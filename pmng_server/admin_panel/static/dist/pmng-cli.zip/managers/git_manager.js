const utils = require("../utils");
const child_process = require("child_process");

function getCommands() {
    return {
        commit: {help: "Commit changes to the Git repository of this project.", needProject: true},
        push: {help: "Push changes to the PMNG Git repository of this project.", needProject: true}
    };
}

function executeCommand(command, args, {quiet, forceYes}) {
    let currentProjectConfig = utils.getProjectConfig();
    switch(command) {
        case "commit":
            utils.checkPMNGFolder(currentProjectConfig);
            utils.checkLoggedIn(save, "committing modifications");

            let all = utils.containsArgument(["-a", "--all"]);
            let push = utils.containsArgument(["-p", "--push"]);
            let message = (args[0] || "").trim(); // position after all/push being removed if necessary

            if(message == "") {
                console.error("Commit message is mandatory.");
                process.exit(1);
            }

            let gitCommit = child_process.spawnSync(...utils.spawnArgs(["git", "commit", all ? "-am" : "-m", message]));
            if(gitCommit.error != undefined || gitCommit.status != 0) {
                console.error("Cannot commit to the repository (status/signal " + (gitCommit.status || gitCommit.signal) + ").");
                console.error("Maybe no changes were detected (try use the -a flag or use 'git add .').");
                process.exit(1);
            }

            console.log("Changes committed.");

            if(!push) break;
        case "push":
            utils.checkPMNGFolder(currentProjectConfig);
            utils.checkLoggedIn(save, "pushing any commit");

            console.log("Pushing changes...");
            if(command == "commit") console.log(""); // margin line when commit and autopush
            child_process.execSync((utils.isWindows ? "" : "/bin/env ") + "git push", {stdio: "inherit"});
            break;
        default:
            return false;
    }

    return true;
}

module.exports.getCommands = getCommands;
module.exports.executeCommand = executeCommand;