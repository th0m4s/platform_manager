const utils = require("../utils");
const execa = require("execa");

function getCommands() {
    return {
        commit: {help: "Commit changes to the Git repository of this project.", needProject: true},
        push: {help: "Push changes to the PMNG Git repository of this project.", needProject: true}
    };
}

function executeCommand(command, args, {quiet, forceYes}) {
    let currentProjectConfig = utils.getProjectConfig(), save = utils.getSave();
    switch(command) {
        case "commit":
            utils.checkPMNGFolder(currentProjectConfig);
            utils.checkLoggedIn(save, "committing modifications");

            let all = utils.containsArgument(["-a", "--all"], args);
            let push = utils.containsArgument(["-p", "--push"], args);
            let message = (args[0] || "").trim(); // position after all/push being removed if necessary

            if(message == "") {
                console.error("Commit message is mandatory.");
                process.exit(1);
            }

            let gitCommit = execa.sync("git", ["commit", all ? "-am" : "-m", '"' + message.replace(/"/g, '\\"') + '"'], {shell: true});
            if(gitCommit.failed || gitCommit.exitCode != 0) {
                console.error("Cannot commit to the repository (status/signal " + (gitCommit.exitCode || gitCommit.killSignal) + ").");
                console.error("Maybe no changes were detected (try use the -a flag or use 'git add .').");
                process.exit(1);
            }

            console.log("Changes committed.");

            if(!push) break;
        case "push":
            utils.checkPMNGFolder(currentProjectConfig);
            utils.checkLoggedIn(save, "pushing any commit");

            console.log("Pushing changes...");
            if(command == "commit") console.log(""); // margin line when commit and autopush
            execa.sync("git", ["push", "pmng", "master"], {stdio: "inherit", shell: true});
            // force correct branch
            break;
        case "pull":
            utils.checkPMNGFolder(currentProjectConfig);
            utils.checkLoggedIn(save, "pulling the repository");

            console.log("Pulling remote project repository...");
            let pullResult = utils.pullProject(true);
            if(pullResult === false) {
                console.error("Could not pull repository. Try running the command 'git pull pmng master' for further details.");
                process.exit(1);
            } else if(pullResult == 1) {
                console.log("Repository updated from remote.");
            } else console.log("Already up to date.");

            break;
        default:
            return false;
    }

    return true;
}

module.exports.getCommands = getCommands;
module.exports.executeCommand = executeCommand;