const utils = require("../utils");
const bent = require("bent");
const compareVersions = require("compare-versions");
const rimraf = require("rimraf");
const path = require("path");
const os = require("os");
const execa = require("execa");
const download = require("../download");
const fs = require("fs");

function getCommands() {
    return {
        uninstall: {help: "Uninstall the CLI from the system.", needRoot: true},
        update: {help: "Check for updates and install one if necessary.", needRoot: true},
        login: {help: "Login to an account on the server specified during the installation."},
        logout: {help: "Logout from an opened session on the system."}
    };
}

async function executeCommand(command, args, {quiet, forceYes}) {
    let save = utils.getSave();
    switch(command) {
        case "paths:dir":
            console.log(save.installPaths.dir);
            break;
        case "paths:link":
        case "path:symlink":
            console.log(save.installPaths.symlink);
            break;
        case "testbuild":
            console.log(save.testBuild ? "true" : "false");
            break;
        case "uninstall":
            if(utils.isWindows || process.getuid() == 0) {
                if(forceYes || (await utils.askConfirmation("Do you uninstall the pmng-cli from your system"))) {
                    if(!forceYes) console.log(""); // margin only if question appears
                    try {
                        let installPaths = save.installPaths;
                        if(save.testBuild) {
                            console.log("Removing development symlink...");
                            fs.unlinkSync(installPaths.symlink);
                            console.log("pmng-cli test build uninstalled.");
                        } else {
                            console.log("Revoving installation directory...");
                            rimraf.sync(installPaths.dir);
                            if(!utils.isWindows) {
                                console.log("Removing pmng-cli symlink...");
                                fs.unlinkSync(installPaths.symlink);
                            }   

                            console.log("pmng-cli was successfully uninstalled from your system.");
                        }
                    } catch(error) {
                        console.error("Cannot uninstall pmng-cli: " + error);
                    }
                }
            } else {
                console.log("Uninstalling on Linux requires root privileges. Please try again with sudo.");
            }
            break;
        case "update":
            if(utils.isWindows || process.getuid() == 0) {
                let query = save.testBuild ? "Updates for test builds are disabled. Do you want to check anyway"
                    : "Do you want to check and install any available update";
                if(forceYes || (await utils.askConfirmation(query))) {
                    let getBent = bent(save.adminServer, "GET", "json");
                    console.log((!forceYes ? "\n" : "") + "Checking for updates..."); // no margin if question not shown
                    try {
                        let versionResp = await getBent("/api/v1/login/version");
                        if(versionResp.error) {
                            console.error("Cannot check for updates: " + versionResp.message);
                        } else {
                            let lastCliVersion = versionResp.cli_version;
                            if(compareVersions(process.env.CLI_VERSION, lastCliVersion) < 0) {
                                console.log("Updating to v" + lastCliVersion + ". Downloading installer...");
                                let installFile = path.resolve(os.tmpdir(), "pmngcli_update_v" + lastCliVersion.split(".").join("_") + "_" + Math.floor(Math.random()*100000));
                                await download(save.adminServer + "/static/pmng-cli_installer.js", installFile);
                                console.log("Executing installer...");

                                let resp = execa.node(installFile, ["--update"], {shell: true});
                                // when run here, output is not shown, so display little message
                                if(resp.error != undefined) {
                                    console.error("Cannot run the updater: " + resp.error);
                                    process.exit(1);
                                } else if(resp.status == 0) {
                                    console.log("\npmng-cli was successfully updated.");
                                    console.log("Run pmng version to check the new installed version.");
                                } else {
                                    console.error("An error occurred while running the updater (status/signal " + (resp.status || resp.signal) + "):\n" + resp.stderr.toString().trim());
                                    process.exit(1);
                                }
                            } else {
                                console.log("Already up-to-date.");
                            }
                        }
                    } catch(error) {
                        try {
                            let response = await error.json();
                            console.error("Cannot check for updates (" + response.code + "): " + response.message);
                        } catch(parseResponse) {
                            console.error("Invalid server response: " + error);
                        }

                        console.log("Please try again.");
                    }
                }
            } else {
                console.log("Updating on Linux requires root privileges. Please try again with sudo.");
            }
            break;
        case "login":
            if(!utils.isLoggedIn(save)) {
                let postBent = bent(save.adminServer, "POST", "json");
                console.log("Please enter your credentials to login into " + save.adminServer + ":");
                
                let user = await utils.askQuestion("Username: ", false);
                let password = await utils.askQuestion("Password: ", true);

                console.log("Logging in...\n");
                try {
                    let loginResult = await postBent("/api/v1/login", {user, password});
                    if(loginResult.error || loginResult.code != 200) {
                        console.error("Cannot login (" +  loginResult.code + "): " + loginResult.message);
                        console.log("Please try again.")
                    } else {
                        save.account = {token: loginResult.key, username: user, sessionId: Math.floor(Math.random()*Number.MAX_SAFE_INTEGER)};
                        utils.editSave(save);

                        console.log("Successfully logged in!");
                    }
                } catch(error) {
                    try {
                        let response = await error.json();
                        console.error("Cannot login (" + response.code + "): " + response.message);
                    } catch(parseResponse) {
                        console.error("Invalid server response: " + error);
                    }

                    console.log("Please try again.");
                }
            } else {
                console.error("You are already logged in. Please first use pmng sys:logout.");
            }
            break;
        case "logout":
            if(!utils.isLoggedIn(save)) {
                console.error("You are not logged in. Please use pmng sys:login.");
            } else {
                if(forceYes || (await utils.askConfirmation("Do you really want to logout"))) {
                    let deleteBent = bent(save.adminServer, "DELETE", "json");
                    console.log("Logging out..." + (forceYes ? "" : "\n"));
                    try {
                        let logoutResult = await deleteBent("/api/v1/login", {}, utils.headerAuth(save.account.token));
                        if(logoutResult.error || logoutResult.code != 200) {
                            console.error("Cannot logout (" +  logoutResult.code + "): " + logoutResult.message);
                            console.log("Please try again.")
                        } else {
                            save.account = undefined;
                            utils.editSave(save);
    
                            console.log("Successfully logged out!");
                            console.log("You will need to login again to access any project/logs related command.");
                        }
                    } catch(error) {
                        try {
                            let response = await error.json();
                            console.error("Cannot logout (" + response.code + "): " + response.message);
                        } catch(parseResponse) {
                            console.error("Invalid server response: " + error);
                        }
    
                        console.log("Please try again.");
                    }
                }
            }
            break;
        default:
            return false;
    }

    return true;
}

module.exports.getCommands = getCommands;
module.exports.executeCommand = executeCommand;