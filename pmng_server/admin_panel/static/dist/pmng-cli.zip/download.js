const { parse } = require('url')
const http = require('http')
const https = require('https')
const fs = require('fs')
const { basename } = require('path')

const TIMEOUT = 10000

module.exports = function(url, path) {
  const uri = parse(url)
  let conn = http;
  if (!path) {
    path = basename(uri.path)
  }
  if(url.startsWith("https://"))
    conn = https;
  const file = fs.createWriteStream(path)

  return new Promise(function(resolve, reject) {
    const request = conn.get(uri.href).on('response', function(res) {
      const len = parseInt(res.headers['content-length'], 10)
      let downloaded = 0
      let percent = 0
      file.on("close", () => {
        resolve();
      });
      res
        .on('data', function(chunk) {
          file.write(chunk)
          downloaded += chunk.length
          percent = (100.0 * downloaded / len).toFixed(2)
          // process.stdout.write(`Downloading ${percent}% ${downloaded} bytes\r`)
        })
        .on('end', function() {
          file.end()
          // console.log(downloaded, percent, len);
          //console.log(`${uri.path} downloaded to: ${path}`)
        })
        .on('error', function (err) {
          reject(err)
        })
    }).on("error", function(err) {
        reject(err);
    })
    request.setTimeout(TIMEOUT, function() {
      request.abort()
      reject(new Error(`request timeout after ${TIMEOUT / 1000.0}s`))
    })
  })
}