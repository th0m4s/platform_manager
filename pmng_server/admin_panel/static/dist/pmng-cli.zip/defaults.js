function checkAction(argv, actionManagers, {quiet, forceYes}) {
    let action = argv[2];
    switch(action) {
        case "version":
        case "sys:version":
            displayVersion(quiet);
            break;
        case "help":
        case "sys:help":
            displayHelp(argv[3], actionManagers);
            break;
        default:
            return false;
    }

    return true;
}

function getCommandCharacter(command) {
    // not a problem with || because default is false
    if(command.needProject || false) return " (*)";
    else if(command.needRoot || false) return " (R)";
    else return "";
}

const helpSpace = "    ";
function displayCommand(manager, command) {
    console.log(helpSpace + manager[0] + ":" + command[0] + getCommandCharacter(command[1]) + " - " + command[1].help);
}

function displayHelp(type, actionManagers) {
    if(type == undefined) {
        console.log("List of available commands:");
        console.log(helpSpace + "help (sys:help) - Display this help.");
        console.log(helpSpace + "version (sys:version) - Show the version of this CLI.");

        let managers = Object.entries(actionManagers);
        for(let manager of managers) {
            console.log("");

            for(let command of Object.entries(manager[1].getCommands()))
                displayCommand(manager, command);
        }
    } else {
        let manager = actionManagers[type];
        if(manager == undefined) console.log("Invalid command type. Please use pmng help to list available commands.");
        else {
            console.log("List of " + type + " commands:");
            for(let command of Object.entries(manager.getCommands()))
                displayCommand([type, manager], command);
        }
    }

    console.log("(*) Require the command to be executed from a PMNG project folder.");
    console.log("(R) Requires root privileges to execute the command (only for Linux systems).");
}

function displayVersion(quiet) {
    if(quiet) console.log("v" + process.env.CLI_VERSION);
    else console.log("Type pmng help to see a list of available commands.");
}


module.exports.checkAction = checkAction;
module.exports.displayVersion = displayVersion;