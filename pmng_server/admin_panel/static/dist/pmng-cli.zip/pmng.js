#!/usr/bin/env node
// can run on windows with .bat file
const defaults = require("./defaults");
const utils = require("./utils");
process.env.CLI_VERSION = "0.2.16";

utils.prepareArguments();
let forceYes = utils.containsArgument(["-y", "--yes"]), quiet = utils.containsArgument(["-q", "--quiet"]);
if(!quiet) {
    console.log("pmng-cli v" + process.env.CLI_VERSION);
    console.log("(c) 2020 Thomas LEDOS\n");
}

let actionManagers = {};

(async () => {
    let argc = process.argv.length;
    if(argc == 2) {
        defaults.displayVersion(quiet);
    } else {
        actionManagers.sys = require("./managers/sys_manager");
        actionManagers.project = require("./managers/project_manager");
        actionManagers.git = require("./managers/git_manager");
        actionManagers.logs = require("./managers/logs_manager");

        let argsCommands = [[["-h", "--help"], "help"], [["-v", "--version"], "version"]];
        for(let argsCommand of argsCommands ) {
            let pos = utils.containsArgument(argsCommand[0], process.argv, true);
            if(pos >= 0) {
                process.argv[pos] = argsCommand[1];
                break;
            }
        }

        let sanitizedArgs = process.argv.filter((arg) => !arg.startsWith("-"));
        if(!defaults.checkAction(sanitizedArgs, actionManagers, {quiet, forceYes})) {
            let parts = sanitizedArgs[2].split(":");
            let main = utils.checkMainManager(parts.splice(0, 1)[0]), manager = actionManagers[main];

            if(manager == undefined || !(await manager.executeCommand(parts.join(":"), process.argv.slice(3, process.argv.length),
                {quiet, forceYes}))) {
                console.error("Unknown command. Please use pmng help to list available commands.");
                process.exit(1);
            }
        }
    }

    process.exit(0);
})();