const fs = require("fs");
const path = require("path");
const readline = require("readline");
const savePath = path.resolve(__dirname, "base_settings.json");
const isWindows = process.platform == "win32";
const rl = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout
});

function getConfigFile(folder) {
    if(folder == undefined) folder = process.cwd();
    return path.resolve(folder, ".pmng.json");
}

function getProjectConfig(folder, throwError = false) {
    let configFile = getConfigFile(folder);
    try {
        return JSON.parse(fs.readFileSync(configFile).toString());
    } catch(error) {
        if(throwError) throw error;
        else return false;
    }
}

function setProjectConfig(save, folder) {
    fs.writeFileSync(getConfigFile(folder), JSON.stringify(save));
}

let save = undefined;
function getSave() {
    if(save == undefined)
        save = JSON.parse(fs.readFileSync(savePath).toString());

    return save;
}

function editSave(save) {
    fs.writeFileSync(savePath, JSON.stringify(save));
}

function isLoggedIn(save) {
    if(save == undefined) save = getSave();
    return save.account != undefined && save.account.token.trim().length > 0;
}

function checkLoggedIn(save, endText) {
    if(!isLoggedIn(save)) {
        console.error("You are not logged in. Please use pmng sys:login" + (endText != undefined ? " before " + endText : "") +".");
        process.exit(1);
    }
}

function headerAuth(token, baseHeaders = {}) {
    if(token == undefined) token = getSave().account.token;
    return Object.assign(baseHeaders, {Authorization: "Api-Key " + token});
}

function containsArgument(allPossible) {
    for(let possible of allPossible) {
        if(process.argv.includes(possible)) {
            process.argv.splice(process.argv.indexOf(possible), 1);
            return true;
        }
    }

    return false;
}

function prepareArguments() {
    let args = [];

    for(let arg of process.argv) {
        if(arg.length >= 2 && arg[0] == "-" && arg[1] != "-")
            for(let i = 1; i < arg.length; i++) args.push("-" + arg[i]);
        else args.push(arg);
    }

    process.argv = args;
}

function pullProject(gotChanges = false) {
    // here pull always use pmng/master because first pull requires it and to counter issues
    let gitPull = child_process.spawnSync(...utils.spawnArgs(["git", "pull", "pmng", "master"]));
    if(gitPull.error != undefined || gitPull.status != 0) return false;
    else if(gotChanges) return gitPull.stdout.toString().includes("Already up to date.") ? 1 : 0; 
    else return true;
}

function checkPMNGFolder(folderConfig) {
    if(folderConfig == false) {
        console.error("This is not a valid PMNG project folder.");
        process.exit(1);
    }
}

// warning some spawnArgs on windows require {shell: true}
function spawnArgs(args) {
    if(!isWindows) return ["/bin/env", args];
    else {
        let command = args.splice(0, 1)[0];
        return [command, args];
    }
}

async function askConfirmation(query) {
    return (await askQuestion(query + " (y/N)? ", false)).toLowerCase() == "y";
}

function askQuestion(query, hidden = false) {
    if(hidden) {
        return new Promise((resolve, reject) => {
            const stdin = process.openStdin();
            process.stdin.on('data', char => {
                char = char + '';
                switch (char) {
                    case '\n':
                    case '\r':
                    case '\u0004':
                        stdin.pause();
                        break;
                    default:
                        process.stdout.clearLine();
                        readline.cursorTo(process.stdout, 0);
                        process.stdout.write(query + Array(rl.line.length + 1).join('*'));
                        break;
                }
            });

            rl.question(query, value => {
                rl.history = rl.history.slice(1);
                resolve(value);
            });
        });
    } else {
        return new Promise((resolve) => {
            rl.question(query, resolve);
        })
    }
}

module.exports.getSave = getSave;
module.exports.editSave = editSave;
module.exports.askQuestion = askQuestion;
module.exports.askConfirmation = askConfirmation;
module.exports.pullProject = pullProject;
module.exports.headerAuth = headerAuth;
module.exports.checkPMNGFolder = checkPMNGFolder;
module.exports.checkLoggedIn = checkLoggedIn;
module.exports.getProjectConfig = getProjectConfig;
module.exports.setProjectConfig = setProjectConfig;
module.exports.isLoggedIn = isLoggedIn;
module.exports.spawnArgs = spawnArgs;
module.exports.containsArgument = containsArgument;
module.exports.prepareArguments = prepareArguments;
module.exports.isWindows = isWindows;