const fs = require("fs");
const path = require("path");
const readline = require("readline");
const savePath = path.resolve(__dirname, "base_settings.json");
const isWindows = process.platform == "win32";
const rl = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout
});

let save = undefined;
function getSave() {
    if(save == undefined)
        save = JSON.parse(fs.readFileSync(savePath).toString());

    return save;
}

function editSave(save) {
    fs.writeFileSync(savePath, JSON.stringify(save));
}

function isLoggedIn(save) {
    if(save == undefined) save = getSave();
    return save.account != undefined && save.account.token.trim().length > 0;
}

function headerAuth(token, baseHeaders = {}) {
    if(token == undefined) token = getSave().account.token;
    return Object.assign(baseHeaders, {Authorization: "Api-Key " + token});
}

function containsArgument(allPossible) {
    for(let possible of allPossible) {
        if(process.argv.includes(possible)) {
            process.argv.splice(process.argv.indexOf(possible), 1);
            return true;
        }
    }

    return false;
}

function prepareArguments() {
    let args = [];

    for(let arg of process.argv) {
        if(arg.length >= 2 && arg[0] == "-" && arg[1] != "-")
            for(let i = 1; i < arg.length; i++) args.push("-" + arg[i]);
        else args.push(arg);
    }

    process.argv = args;
}

function askQuestion(query, hidden = false) {
    if(hidden) {
        return new Promise((resolve, reject) => {
            const stdin = process.openStdin();
            process.stdin.on('data', char => {
                char = char + '';
                switch (char) {
                    case '\n':
                    case '\r':
                    case '\u0004':
                        stdin.pause();
                        break;
                    default:
                        process.stdout.clearLine();
                        readline.cursorTo(process.stdout, 0);
                        process.stdout.write(query + Array(rl.line.length + 1).join('*'));
                        break;
                }
            });

            rl.question(query, value => {
                rl.history = rl.history.slice(1);
                resolve(value);
            });
        });
    } else {
        return new Promise((resolve) => {
            rl.question(query, resolve);
        })
    }
}

module.exports.getSave = getSave;
module.exports.editSave = editSave;
module.exports.askQuestion = askQuestion;
module.exports.headerAuth = headerAuth;
module.exports.isLoggedIn = isLoggedIn;
module.exports.containsArgument = containsArgument;
module.exports.prepareArguments = prepareArguments;
module.exports.isWindows = isWindows;